void main ();

void print(char*message)
{
  char *p_vide_buffer = (char*) 0xb8140


;
  char *p_next_char = message;
  while(*p_next_char){
    *p_vide_buffer= *p_next_char;
    p_next_char++;
    p_vide_buffer+=2;
  }
}

void main(){
  print("We are running our C kernel");
  while(1){

  }
}
